/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consumidor;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cetecom
 */
public class Consumidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List<consumidor.Conductores> lista = new ArrayList<consumidor.Conductores>();
        lista = todosTransporte();
        
        System.out.println("Lista");
        for (Conductores c : lista) {
            System.out.println(c.getNombres() + " " + c.getApellidos());
        }
        
        System.out.println("");
        System.out.println("Buscar por id");
        Conductores conductor = new Conductores();
        
        Integer id = 2;
        conductor = buscarId(id);
        System.out.println(conductor.getNombres() + " " + conductor.getApellidos());
        
        System.out.println("Buscar por nombre");
        Conductores conductor2 = new Conductores();
        conductor2 = buscarNombre("cesar");
        System.out.println(conductor2.getNombres() + " " + conductor2.getApellidos());
    }

    private static java.util.List<consumidor.Conductores> todosTransporte() {
        consumidor.WebServiceTransporte_Service service = new consumidor.WebServiceTransporte_Service();
        consumidor.WebServiceTransporte port = service.getWebServiceTransportePort();
        return port.todosTransporte();
    }

    private static Conductores buscarId(java.lang.Object arg0) {
        consumidor.WebServiceTransporte_Service service = new consumidor.WebServiceTransporte_Service();
        consumidor.WebServiceTransporte port = service.getWebServiceTransportePort();
        return port.buscarId(arg0);
    }

    private static Conductores buscarNombre(java.lang.String arg0) {
        consumidor.WebServiceTransporte_Service service = new consumidor.WebServiceTransporte_Service();
        consumidor.WebServiceTransporte port = service.getWebServiceTransportePort();
        return port.buscarNombre(arg0);
    }

    

    
}
