/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.duoc.wstransporte;

import com.duoc.orquesta.Conductores;
import com.duoc.orquesta.NewWebService_Service;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author cetecom
 */
@WebService(serviceName = "WebServiceTransporte")
public class WebServiceTransporte {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/WS1/NewWebService.wsdl")
    private NewWebService_Service service;

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "todosTransporte")
    public List<com.duoc.orquesta.Conductores> todosTransporte() {
        return findAll();
    }

    private java.util.List<com.duoc.orquesta.Conductores> findAll() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.duoc.orquesta.NewWebService port = service.getNewWebServicePort();
        return port.findAll();
    }

    private void remove(com.duoc.orquesta.Conductores entity) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.duoc.orquesta.NewWebService port = service.getNewWebServicePort();
        port.remove(entity);
    }

    private void create(com.duoc.orquesta.Conductores entity) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.duoc.orquesta.NewWebService port = service.getNewWebServicePort();
        port.create(entity);
    }

    private void edit(com.duoc.orquesta.Conductores entity) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.duoc.orquesta.NewWebService port = service.getNewWebServicePort();
        port.edit(entity);
    }

    @WebMethod(operationName = "buscarId")
    public Conductores buscarId(java.lang.Object id) {
        return find(id);
    }    
    
    private Conductores find(java.lang.Object id) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.duoc.orquesta.NewWebService port = service.getNewWebServicePort();
        return port.find(id);
    }

    @WebMethod(operationName = "buscarNombre")
    public Conductores buscarNombre(java.lang.String nombre) {
        return findName(nombre);
    } 
    
    private Conductores findName(java.lang.String nombre) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.duoc.orquesta.NewWebService port = service.getNewWebServicePort();
        return port.findName(nombre);
    }
    
    
    
    
}
