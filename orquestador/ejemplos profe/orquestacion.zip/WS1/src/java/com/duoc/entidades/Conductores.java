/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.duoc.entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author cetecom
 */
@Entity
@Table(name = "conductores", catalog = "transportes", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Conductores.findAll", query = "SELECT c FROM Conductores c"),
    @NamedQuery(name = "Conductores.findById", query = "SELECT c FROM Conductores c WHERE c.id = :id"),
    @NamedQuery(name = "Conductores.findByNombres", query = "SELECT c FROM Conductores c WHERE c.nombres = :nombres"),
    @NamedQuery(name = "Conductores.findByApellidos", query = "SELECT c FROM Conductores c WHERE c.apellidos = :apellidos"),
    @NamedQuery(name = "Conductores.findByNacimiento", query = "SELECT c FROM Conductores c WHERE c.nacimiento = :nacimiento"),
    @NamedQuery(name = "Conductores.findByEstadoCivil", query = "SELECT c FROM Conductores c WHERE c.estadoCivil = :estadoCivil"),
    @NamedQuery(name = "Conductores.findByDomicilio", query = "SELECT c FROM Conductores c WHERE c.domicilio = :domicilio"),
    @NamedQuery(name = "Conductores.findByCiudad", query = "SELECT c FROM Conductores c WHERE c.ciudad = :ciudad"),
    @NamedQuery(name = "Conductores.findByPais", query = "SELECT c FROM Conductores c WHERE c.pais = :pais"),
    @NamedQuery(name = "Conductores.findByTelefono", query = "SELECT c FROM Conductores c WHERE c.telefono = :telefono"),
    @NamedQuery(name = "Conductores.findByLicencia", query = "SELECT c FROM Conductores c WHERE c.licencia = :licencia")})
public class Conductores implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nombres", nullable = false, length = 100)
    private String nombres;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "apellidos", nullable = false, length = 100)
    private String apellidos;
    @Column(name = "nacimiento")
    @Temporal(TemporalType.DATE)
    private Date nacimiento;
    @Size(max = 20)
    @Column(name = "estado_civil", length = 20)
    private String estadoCivil;
    @Size(max = 255)
    @Column(name = "domicilio", length = 255)
    private String domicilio;
    @Size(max = 50)
    @Column(name = "ciudad", length = 50)
    private String ciudad;
    @Size(max = 50)
    @Column(name = "pais", length = 50)
    private String pais;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "telefono", nullable = false, length = 50)
    private String telefono;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "licencia", nullable = false, length = 50)
    private String licencia;

    public Conductores() {
    }

    public Conductores(Integer id) {
        this.id = id;
    }

    public Conductores(Integer id, String nombres, String apellidos, String telefono, String licencia) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.licencia = licencia;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Date getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(Date nacimiento) {
        this.nacimiento = nacimiento;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getLicencia() {
        return licencia;
    }

    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Conductores)) {
            return false;
        }
        Conductores other = (Conductores) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.duoc.entidades.Conductores[ id=" + id + " ]";
    }
    
}
